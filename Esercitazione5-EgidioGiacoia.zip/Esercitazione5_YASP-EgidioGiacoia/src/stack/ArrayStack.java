package stack;

public class ArrayStack<E> implements Stack<E> {
	protected int capacity;
	public static final int CAPACITY = 10;
	protected E S[];
	protected int top = -1;
	public ArrayStack(){
		this(CAPACITY);
	}
	public ArrayStack(int cap){
		capacity = cap;
		S = (E[]) new Object[capacity];
	}
	public int size() {
		return top+1;
	}

	public boolean isEmpty() {
		return (top < 0);
	}

	public E top() throws EmptyStackException {
		if (isEmpty())
			throw new EmptyStackException("Stack is empty.");
		return S[top];
	}

	public void push(E element) {
		if(size() == capacity)
			throw new FullStackException("Stack is full.");
		S[++top] = element;
	}

	public E pop() throws EmptyStackException {
		E element;
		if (isEmpty())
			throw new EmptyStackException("Stack is empty.");
		element = S[top];
		S[top--] = null;
		return element;
	}
	
}
