package support;

public class IdentifierNotDeclared extends Exception{

	public IdentifierNotDeclared(String msg) {
		super(msg);
	}
}
