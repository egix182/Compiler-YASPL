package support;


import syntaxTree.VisitableNode;
import tree.Position;

public class Token<E> {

    private String name;    
	private Attribute<E> attribute;
	private Position<VisitableNode> node;

	public Token(String name, Attribute<E> attribute){
		this.name = name;
		this.attribute = attribute;
	}
	
	public Token(String name){
		this.name = name;
		this.attribute = null;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Attribute<E> getAttribute() {
		return attribute;
	}

	public void setAttribute(Attribute<E> attribute) {
		this.attribute = attribute;
	}
	
	public VisitableNode getNode() {
		return node.element();
	}
	
	public Position<VisitableNode> getPositionNode() {
		return node;
	}
	
	public void setNode(Position<VisitableNode> node) {
		this.node = node;
	}

	
	public String toString(){
		String toReturn =  attribute==null? name : "("+name+", \""+attribute.toString()+"\")";
		if(node == null) return toReturn;
		if(getNode().getSpecialType() != null) return toReturn+"("+getNode().getType()+")"+"("+getNode().getSpecialType()+")";
		else return toReturn+"("+getNode().getType()+")";
		
	}
}
