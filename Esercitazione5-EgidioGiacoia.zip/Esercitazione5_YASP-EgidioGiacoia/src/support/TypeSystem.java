package support;

import java.util.Iterator;

import syntaxTree.Leaf;
import syntaxTree.VisitableNode;
import tree.NodePositionList;
import tree.Position;

public class TypeSystem {
	 public static final int ERROR = 0;
	 public static final int INT = 1;
	 public static final int DOUBLE = 2;
	 public static final int STRING = 3;
	 public static final int CHAR = 4;
	 public static final int BOOL = 5;
	 public static final int VOID = 6;
	 

	 
	  public static final String[] typeName = new String[] {
			  "error",
			  "int",
			  "double",
			  "string",
			  "char",
			  "bool",
			  "void"
			  };
	  
/*  	public static int convertNameToInt(String name) {
		return convertConstToInt(name);
	}
	public static int convert(String name) {
		for(int i = 0; i<typeName.length; i++) {
			if(name == typeName[i])  return i-1;
		}
		return ERROR;
	}
	
	public static int convertConstToInt(String name) {
		switch(name) {
		case"int_const": return convert(typeName[INT]);
		case"double_const": return convert(typeName[DOUBLE]);
		case"string_const": return convert(typeName[STRING]);
		case"char_const": return convert(typeName[CHAR]);
		case"true": 
		case"false": return convert(typeName[BOOL]);
		default: return convert(name);
		}
	}*/
	  
	  public static final int[][] addOpTable = new int[][] {
		  { INT, DOUBLE, 0, 0, 0, 0 }, //int
		  { DOUBLE, DOUBLE, 0, 0, 0, 0 }, //double
		  { 0, 0, 0, 0, 0, 0}, //string
		  { 0, 0, 0, 0, 0, 0}, //char
		  { 0, 0, 0, 0, 0, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] diffOpTable = new int[][] {
		  { INT, DOUBLE, 0, 0, 0, 0 }, //int
		  { DOUBLE, DOUBLE, 0, 0, 0, 0 }, //double
		  { 0, 0, 0, 0, 0, 0}, //string
		  { 0, 0, 0, 0, 0, 0}, //char
		  { 0, 0, 0, 0, 0, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] MulOpTable = new int[][] {
		  { INT, DOUBLE, 0, 0, 0, 0 }, //int
		  { DOUBLE, DOUBLE, 0, 0, 0, 0 }, //double
		  { 0, 0, 0, 0, 0, 0}, //string
		  { 0, 0, 0, 0, 0, 0}, //char
		  { 0, 0, 0, 0, 0, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] DivOpTable = new int[][] {
		  { INT, DOUBLE, 0, 0, 0, 0 }, //int
		  { DOUBLE, DOUBLE, 0, 0, 0, 0 }, //double
		  { 0, 0, 0, 0, 0, 0}, //string
		  { 0, 0, 0, 0, 0, 0}, //char
		  { 0, 0, 0, 0, 0, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] assignOpTable = new int[][] {
		  { INT, INT, 0, 0, 0, 0 }, //int
		  { DOUBLE, DOUBLE, 0, 0, 0, 0 }, //double
		  { 0, 0, STRING, STRING, 0, 0}, //string
		  { 0, 0, 0, CHAR, 0, 0}, //char
		  { 0, 0, 0, 0, BOOL, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] relOpTable = new int[][] {
		  { BOOL, BOOL, 0, 0, 0, 0 }, //int
		  { BOOL, BOOL, 0, 0, 0, 0 }, //double
		  { 0, 0, 0, 0, 0, 0}, //string
		  { 0, 0, 0, 0, 0, 0}, //char
		  { 0, 0, 0, 0, 0, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[][] EQOpTable = new int[][] {
		  { BOOL, BOOL, 0, 0, 0, 0 }, //int
		  { BOOL, BOOL, 0, 0, 0, 0 }, //double
		  { 0, 0, BOOL, 0, 0, 0}, //string
		  { 0, 0, 0, BOOL, 0, 0}, //char
		  { 0, 0, 0, 0, BOOL, 0}, //bool
		  { 0, 0, 0, 0, 0, 0}, //void
	  };
	  
	  public static final int[] uMinusTable = new int[] {
		  INT, DOUBLE, 0, 0, 0, 0 
	  };
	  
	public static int convertNameToInt(String name) {
		for(int i = 0; i<typeName.length; i++) {
			if(name == typeName[i])  return i-1;
		}
		return ERROR;
	}
	
	public static int convertConstToInt(String name) {
		for(int i = 0; i<typeName.length; i++) {
			if(name == typeName[i])  return i-1;
		}
		return ERROR;
	}
	
	public static String conditionOp(String label, Position<VisitableNode> node) throws TypeMismatch {
		if(node.element().getType() == typeName[BOOL]) return typeName[VOID];
		else throw new TypeMismatch(label+"Condition Invalid:" +node.element().getType());
	}
	
	public static String compStatOp() {
		return typeName[VOID];
	}
	
	public static String assignOp(Position<VisitableNode> nodeLeft, Position<VisitableNode> nodeRight) throws TypeMismatch {
		int type = assignOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
		if(type != ERROR) {
			return typeName[VOID];
		}else throw new TypeMismatch("Assign Operation Invalid: "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
	}
	

	public static String relOp(String label, Position<VisitableNode> nodeLeft, Position<VisitableNode> nodeRight) throws TypeMismatch {
		int type;
		switch(label) {
		case "EQOp":
			type = EQOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		default:
			type = relOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		}
	}
	
	public static String notOp(Position<VisitableNode> node) throws TypeMismatch {
		if(node.element().getType() == typeName[BOOL]) return typeName[BOOL];
		else throw new TypeMismatch("NotOp Condition Invalid:" +node.element().getType());
	}
	
	public static String artOp(String label, Position<VisitableNode> nodeLeft, Position<VisitableNode> nodeRight) throws TypeMismatch {
		int type;
		switch(label) {
		case "AddOp":
			type = addOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		case "DiffOp":
			type = diffOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		case "MulOp":
			type = diffOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		case "DivOp":
			type = diffOpTable[convertNameToInt(nodeLeft.element().getType())][convertNameToInt(nodeRight.element().getType())];
			if(type != ERROR) {
				return typeName[type];
			}else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
		default: break;
		}
		return typeName[ERROR];
	}
	
	public static String boolOp(String label, Position<VisitableNode> nodeLeft, Position<VisitableNode> nodeRight) throws TypeMismatch {
		if(nodeLeft.element().getType() == typeName[BOOL] && nodeRight.element().getType() == typeName[BOOL] ) return typeName[BOOL];
		else throw new TypeMismatch(label +": "+nodeLeft.element().getType() +"-"+nodeRight.element().getType());
	}
	
	public static String uMinusOp(Position<VisitableNode> node) throws TypeMismatch {
		int type = uMinusTable[convertNameToInt(node.element().getType())];
		if(type != ERROR) {
			return typeName[type];
		}else throw new TypeMismatch("UMinus Operation Invalid: "+node.element().getType());
	}
	
	public static String callOp(NodePositionList<Position<VisitableNode>> listCall, NodePositionList<Position<VisitableNode>> listFunc, String typeToReturn) throws TypeMismatch {
		if(listCall.size() != listFunc.size()) throw new TypeMismatch("Call Operation Invalid: numbers of arguments Invalid");
		Iterator<Position<VisitableNode>> iteratorCall  = listCall.iterator();
		Iterator<Position<VisitableNode>> iteratorFunc  = listFunc.iterator();
		String type="";
		while(iteratorCall.hasNext() && iteratorFunc.hasNext()) {
			Position<VisitableNode> callNode = iteratorCall.next();
			Position<VisitableNode> funcNode = iteratorFunc.next();
			if(!(callNode.element().getType().equals(""+((Leaf)funcNode.element()).getValue())))
				throw new TypeMismatch("Call Operation Invalid:  Malformed Type Argument");
		}
		
		return typeToReturn;
	}
	
	public static void 	checkUsageParFunction(Position<VisitableNode> node, Position<VisitableNode> parent) throws TypeMismatch {
		String typePar = node.element().getSpecialType();
		if(typePar != "INOUT") {
			switch(parent.element().getLabel()) {
			case"AssignOp":
			case"WriteOp": if(typePar.equals("IN")) throw new TypeMismatch("Parameter Usage Invalid: "+node.element().getLabel()+"-"+parent.element().getLabel());	
			break;
			case"CallOp":
			case"ReadOp":  
			default:
				if(typePar.equals("OUT")) throw new TypeMismatch("Parameter Usage Invalid: "+node.element().getLabel()+"-"+parent.element().getLabel());
				break;
			}
		}
		
	}

}
