package support;

import stack.ArrayStack;
import stack.EmptyStackException;

public class TableArrayStack implements Cloneable{
	
	private ArrayStack<TableOfSymbols> stack;
	private ArrayStack<TableOfSymbols> stackReverse;
	private TableOfSymbols currentScope;
	
	public TableArrayStack() {
		stack = new ArrayStack<TableOfSymbols>();
		stackReverse = new ArrayStack<TableOfSymbols>();
		currentScope = null;
	}

	public void enterScope(TableOfSymbols tb) {
		stack.push(tb);
		currentScope = stack.top();
	}
	
	public Token lookup(String key) {
		/*if(stack.isEmpty()) { recovery(); return null; }
		Token t = currentScope.checkLessema(key);
		if(t == null) {
			stackReverse.push(stack.pop());
			currentScope = stack.top();
			lookup(key);
		}
		recovery();
		return t;*/
		Token t = null;
		while(!stack.isEmpty()) {
			currentScope = stack.top();
			t = currentScope.checkLessema(key);
			if(t != null) { recovery(); return t;}
			stackReverse.push(stack.pop());
		}
		recovery();
		return null;
	}
	
	public void recovery() {
		while(!stackReverse.isEmpty()) {
			stack.push(stackReverse.pop());
		}
		currentScope = stack.top();
	}
	
	public Token addId(String nomeToken, Object lessema) throws MultipleDeclarationException {
		if(currentScope.checkLessema(lessema) != null) {
			throw new MultipleDeclarationException("Dichirazione Multipla:\""+lessema+"\"");
		}
		return currentScope.installToken(nomeToken, lessema);
	}
	
	public TableOfSymbols exitScope() {
		TableOfSymbols tb = null;
		try{
			tb =  stack.pop();
			currentScope = stack.top();
		}catch(EmptyStackException e) { currentScope = null;};
		return tb;
	}
	
	public TableOfSymbols getCurrentScope() {
		return currentScope;
	}
	
	public int getSizeStack() {
		return stack.size();
	}

	public TableArrayStack clone() {
		try {
			return (TableArrayStack) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e);
		}
	}
}
