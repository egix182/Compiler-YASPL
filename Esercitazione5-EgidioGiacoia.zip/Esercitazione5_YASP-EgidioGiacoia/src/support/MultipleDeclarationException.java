package support;

public class MultipleDeclarationException extends Exception{

	public MultipleDeclarationException(String msg) {
		super(msg);
	}
}
