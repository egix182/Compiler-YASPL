package support;

import java.util.HashMap;
import java.util.Map.Entry;

public class TableOfSymbols {
	private  HashMap<String, Token> tableSymbols;
	
	public TableOfSymbols() {
		tableSymbols = new  HashMap<String, Token>();
	}

	public Token installToken(String nomeToken, Object lessema) {
		Token token;
	
		if(tableSymbols.containsKey((String)lessema))
			return tableSymbols.get((String)lessema);
		else{
			
			if(lessema instanceof Integer) 
				token =  new Token<Integer>(nomeToken.toUpperCase(), new Attribute<Integer>((Integer)lessema));
			else if(lessema instanceof Double)
				token =  new Token<Double>(nomeToken.toUpperCase(), new Attribute<Double>((Double)lessema));
			else if(lessema instanceof Character)
				token =  new Token<Character>(nomeToken.toUpperCase(), new Attribute<Character>((Character)lessema));
			else token =  new Token<String>(nomeToken.toUpperCase(), new Attribute<String>((String)lessema));
				
			tableSymbols.put((String)lessema, token);
			return token;
		}
	}
	
	public Token checkLessema(Object lessema) {
		if(tableSymbols.containsKey((String)lessema))
			return tableSymbols.get((String)lessema);
		return null;
	}
	
	public void printTable() {
		for (Entry<String, Token> entry : tableSymbols.entrySet()) {
		    String key = entry.getKey();
		    Token value = (Token) entry.getValue();
		    System.out.println("[Index:"+key+"]["+value.toString()+"]");
		}
	}

}
