package support;

public class TypeMismatch extends Exception{

	public TypeMismatch(String msg) {
		super(msg);
	}
}
