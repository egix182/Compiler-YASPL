package support;

public class Attribute<E>{
	private E lessema;
	
	public Attribute(E lessema) {
		this.lessema = lessema;
	}

	public E getLessema() {
		return lessema;
	}

	public void setLessema(E lessema) {
		this.lessema = lessema;
	}

	@Override
	public String toString() {
		return getLessema().toString();
	}
	
	
}
