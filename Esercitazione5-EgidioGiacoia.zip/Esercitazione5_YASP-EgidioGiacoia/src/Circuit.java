import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import syntaxTree.*;
import Visitor.*;
import Visitor.GenerationCSource;
import Visitor.PrintXMLTree;
import Visitor.ScopingTree;
import Visitor.TypeCheckingTree;
import java_cup.runtime.Symbol;
import tree.NodePositionList;
import tree.Position;
import tree.PositionList;



public class Circuit {
	
	public static void main(String[] args) throws Exception  {
		//private String path="C:\\Users\\utente\\AppData\\Local\\Packages\\CanonicalGroupLimited.UbuntuonWindows_79rhkp1fndgsc\\LocalState\\rootfs\\home\\egix\\compilatori\\source.c";

		String input="programma_es4.txt";
		String output="source.c";
		 if (args.length > 0) { 
			 input = args[0];
		}else {
			//throw new IOException("No input file");
		}
		InputStream inputStream = new FileInputStream(new File(input));
		
		Yylex l = new Yylex(inputStream);
		
		CircuitCup p = new CircuitCup(l);
		//p.parser(new Yylex(new FileReader(filePath)));
		try{
			p.parse();
		}catch(Exception e) {e.printStackTrace();}
		
	 	
		ScopingTree sct = new ScopingTree(p.getSyntaxTree());
   	 	sct.createScopingTables(p.getSyntaxTree().root());
   	 	sct.printScopingTables();
   	 	
   	 	TypeCheckingTree tct = new TypeCheckingTree(p.getSyntaxTree());
   	 	tct.evalutateTree(p.getSyntaxTree().root());
   	 	PrintXMLTree xml = new PrintXMLTree(p.getSyntaxTree());
	 	xml.visit(p.getSyntaxTree().root());
	 	xml.saveFileXML();
	 	
	 	GenerationCSource g = new GenerationCSource(p.getSyntaxTree(), output);
	 	g.evalutateTree(p.getSyntaxTree().root());
	 	g.saveFile();
	}

}

