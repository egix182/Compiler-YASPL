package syntaxTree;

public class FuncDeclarationNode extends ScopingNode{
	
	public FuncDeclarationNode(String label) {
		super(label);
	}
}
