package syntaxTree;

public class ParDeclarationNode extends VisitableNode{
	
	public ParDeclarationNode(String label) {
		super(label);
	}
}
