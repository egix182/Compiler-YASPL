package syntaxTree;

public class IDNode<E> extends Leaf<E>{
	public IDNode(String label, E value) {
		super(label, value);
	}
}
