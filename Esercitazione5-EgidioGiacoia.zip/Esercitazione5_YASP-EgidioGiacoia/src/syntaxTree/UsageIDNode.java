package syntaxTree;

public class UsageIDNode<E> extends IDNode<E>{
	    
	public UsageIDNode(String label, E value) {
		super(label, value);
	}
}
