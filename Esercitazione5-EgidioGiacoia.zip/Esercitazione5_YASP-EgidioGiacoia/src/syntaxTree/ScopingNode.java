package syntaxTree;

public class ScopingNode extends VisitableNode{
	
	public ScopingNode(String label) {
		super(label);
	}
}
