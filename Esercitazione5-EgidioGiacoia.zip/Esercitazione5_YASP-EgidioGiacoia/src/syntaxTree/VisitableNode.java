package syntaxTree;

import support.TableOfSymbols;
import support.TypeSystem;
import tree.Position;

public class VisitableNode  {
	
    private String label;
    private TableOfSymbols tb = null;
    private String type;
    private String SpecialType;
    
    public VisitableNode(String label) {
    	this.label = label;
    	this.type = null;
    	this.SpecialType = null;
    }

  
	public String getLabel() {
		return label;
	}
	
	public TableOfSymbols getTableOfSymbols() {
		return tb;
	}
	
	public void setTableOfSymbols(TableOfSymbols tb) {
		this.tb = tb;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}


	public String getSpecialType() {
		return SpecialType;
	}


	public void setSpecialType(String specialType) {
		SpecialType = specialType;
	}
	
	
	
}
