package syntaxTree;

public class ConstNode<E> extends Leaf<E>{
		
	public ConstNode(String label, String type, E value) {
		super(label,value);
		this.setType(type);
	}
}
