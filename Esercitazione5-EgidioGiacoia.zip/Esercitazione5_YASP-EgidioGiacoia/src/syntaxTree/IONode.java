package syntaxTree;

import java.util.ArrayList;

public class IONode<E> extends TypedNode<E>{

	private E value;
	private ArrayList<String> listType;
	
	public IONode(String label, E value) {
		super(label);
		this.value = value;
		this.listType = new ArrayList<String>();
	} 
	
	public IONode(String label) {
		super(label);
		this.listType = new ArrayList<String>();
	}
	
	public E getValue() {
		return value;
	}
	
	public void setValue(E value) {
		this.value =  value;
	}

	@Override
	public String getType() {
		String toReturn="";
		int i=0;
		for(String s: listType) {
			if(i==0) toReturn+=s;
			else toReturn+="-"+s;
			i++;
		}
		return toReturn;
	}
	
	@Override
	public void setType(String type) {
		this.listType = new ArrayList<String>();
		listType.add(type);
	}
	
	public void addTypeInList(String type) {
		listType.add(type);;
	}
	
	public ArrayList<String> getListType() {
		return listType;
	}

	public void setListType(ArrayList<String> listType) {
		this.listType = listType;
	}
	
	
}

