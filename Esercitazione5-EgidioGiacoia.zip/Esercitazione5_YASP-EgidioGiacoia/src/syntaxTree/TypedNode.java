package syntaxTree;

public class TypedNode<E> extends VisitableNode{

	private E value;
	
	public TypedNode(String label, E value) {
		super(label);
		this.value = value;
	}
	
	public TypedNode(String label) {
		super(label);
	}
	
	public E getValue() {
		return value;
	}
	
	public void setValue(E value) {
		this.value =  value;
	}
}

