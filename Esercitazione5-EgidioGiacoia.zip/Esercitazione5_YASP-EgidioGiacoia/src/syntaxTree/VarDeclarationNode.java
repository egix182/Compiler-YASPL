package syntaxTree;

public class VarDeclarationNode extends VisitableNode{
	
	public VarDeclarationNode(String label) {
		super(label);
	}
}
