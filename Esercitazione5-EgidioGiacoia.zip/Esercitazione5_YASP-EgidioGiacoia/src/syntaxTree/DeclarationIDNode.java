package syntaxTree;

public class DeclarationIDNode<E> extends IDNode<E>{
	    
	public DeclarationIDNode(String label, E value) {
		super(label, value);
	}
}
