package syntaxTree;

public class ExpressionNode<E> extends TypedNode<E>{

	private E value;
	
	public ExpressionNode(String label, E value) {
		super(label);
		this.value = value;
	}
	
	public ExpressionNode(String label) {
		super(label);
	}
	
	public E getValue() {
		return value;
	}
	
	public void setValue(E value) {
		this.value =  value;
	}
}

