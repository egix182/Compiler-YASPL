package syntaxTree;

public class Leaf<E> extends VisitableNode{
	
	private E value;
	
	public Leaf(String label, E value) {
		super(label);
		this.value = value;
	}
	
	public Leaf(String label) {
		super(label);
	}
	
	public E getValue() {
		return value;
	}
	
	public void setValue(E value) {
		this.value =  value;
	}
	
}
	
