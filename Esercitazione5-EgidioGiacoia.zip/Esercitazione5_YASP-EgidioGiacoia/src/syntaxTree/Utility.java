package syntaxTree;

import java.util.Iterator;

import tree.NodePositionList;
import tree.Position;
import tree.TreeNode;
import tree.TreePosition;

public class Utility {

	public static  <E> NodePositionList<Position<E>> merge (NodePositionList<Position<E>> list1, NodePositionList<Position<E>> list2){
		 Iterator<Position<E>> it =  list2.iterator();
		 while(it.hasNext()) {
			 list1.addLast(it.next());
		 }
		 return list1;
	}
	
	public static <E> void setParentChildren(TreeNode<E> parent) {
		 NodePositionList<Position<E>> children = (NodePositionList<Position<E>>) parent.getChildren();
		 Iterator<Position<E>> it =  children.iterator();
		 while(it.hasNext()) {
			 TreeNode<E> elm = 	(TreeNode<E>) it.next();
			 elm.setParent(parent);
		 }
	}
}
