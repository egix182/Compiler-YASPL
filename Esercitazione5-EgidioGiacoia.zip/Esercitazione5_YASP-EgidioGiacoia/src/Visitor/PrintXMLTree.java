package Visitor;

import syntaxTree.*;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Iterator;

import tree.LinkedTree;
import tree.Position;

public class PrintXMLTree{

	LinkedTree<VisitableNode> tree;
	private String content = "";
	
	public PrintXMLTree(LinkedTree<VisitableNode> tree) {
		this.tree = tree;
	}
	

	
	public String getContent() {
		return this.content;
	}


	public String visit(Position<VisitableNode> node) {
		this.content += "<"+node.element().getLabel()+">\n";
		if(tree.isInternal(node) == true)
		{	
			 if(node.element() instanceof TypedNode) {
				 	TypedNode l = (TypedNode) node.element();
					if(l.getValue() != null) this.content +="Valore: "+ l.getValue();
					if(l.getType() != null) this.content += " Tipo:"+l.getType(); //typechecking
			}
			 Iterable<Position<VisitableNode>> it = tree.children(node);
			 Iterator<Position<VisitableNode>> iterator = it.iterator();
			 while(iterator.hasNext())
			 {
				 Position<VisitableNode> node2 =  iterator.next();
				 visit(node2);
			 }
		}
		if(node.element() instanceof Leaf) {
			Leaf l = (Leaf) node.element();
			if(l.getValue() != null) this.content +="Valore: "+ l.getValue();
			if(l.getType() != null) this.content += " Tipo:"+l.getType(); //typechecking
		}
		this.content += "</"+node.element().getLabel()+">\n";
		//this.content += String.format("</%s>\n", node.element().getLabel());
		return this.content;
	}
	
	 public void saveFileXML(){
	        Writer writer = null;

	        try {
	            writer = new BufferedWriter(new OutputStreamWriter(
	                    new FileOutputStream("syntaxTree.xml"), "utf-8"));
	            writer.write(this.content);
	            writer.close();
	        } catch (IOException ex) {
	            System.out.println("Errore nella scrittura del file");
	        } finally {
	            try {writer.close();} catch (Exception ex) {
	                System.out.println("Errore durante la chiusura del file");
	            }
	        }
	    }
}
