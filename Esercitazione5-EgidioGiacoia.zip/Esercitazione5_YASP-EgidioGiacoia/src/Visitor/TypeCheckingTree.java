package Visitor;

import syntaxTree.*;
import java.util.Iterator;

import support.IdentifierNotDeclared;
import support.TableArrayStack;
import support.TableOfSymbols;
import support.Token;
import support.TypeMismatch;
import support.TypeSystem;
import tree.LinkedTree;
import tree.NodePositionList;
import tree.Position;

public class TypeCheckingTree {
	
	private TableArrayStack stack;
	private LinkedTree<VisitableNode> tree;
	private TableOfSymbols current_table_ref;

	public TypeCheckingTree(LinkedTree<VisitableNode> tree) {
		this.tree = tree;
		stack = new TableArrayStack();
	}
	
	public void valutateTypeInternalNode(Position<VisitableNode> node) throws TypeMismatch {
		Iterable<Position<VisitableNode>> it = tree.children(node);
		Iterator<Position<VisitableNode>> iterator = it.iterator();
		Position<VisitableNode> nodeLeft = null, nodeRight = null;
		switch(node.element().getLabel()) {
			case "WhileOp":
			case "IfThenElseOp":
			case "IfThenOp":
				if(iterator.hasNext()) { 
					nodeLeft =  iterator.next(); 
					node.element().setType(TypeSystem.conditionOp(node.element().getLabel(),nodeLeft)); 
				}
				break;
			case "VarInitOp":
			case "AssignOp":
				if(iterator.hasNext()) nodeLeft =  iterator.next(); 
				else break;
				if(iterator.hasNext()) { 
					nodeRight =  iterator.next(); 
					if(!nodeRight.element().getLabel().equals("null")) node.element().setType(TypeSystem.assignOp(nodeLeft, nodeRight)); 
				}
				break;
			case "CompStatOp":
					node.element().setType(TypeSystem.compStatOp()); 
				break;
			case"GTOp":
			case"GEOp":
			case"LTOp":
			case"LEOp":
			case"EQOp":
				if(iterator.hasNext()) nodeLeft =  iterator.next(); 
				else break;
				if(iterator.hasNext()) { 
					nodeRight =  iterator.next(); 
					node.element().setType(TypeSystem.relOp(node.element().getLabel(), nodeLeft, nodeRight)); 
				}
				break;
			case "NotOp":
				if(iterator.hasNext()) { 
					nodeLeft =  iterator.next(); 
					node.element().setType(TypeSystem.notOp(nodeLeft)); 
				}
				break;
			case "AddOp":
			case "DiffOp":
			case "MulOp":
			case "DivOp":
				if(iterator.hasNext()) nodeLeft =  iterator.next(); 
				else break;
				if(iterator.hasNext()) { 
					nodeRight =  iterator.next(); 
					node.element().setType(TypeSystem.artOp(node.element().getLabel(), nodeLeft, nodeRight)); 
				}
				break;
			case "OrOp":
			case "AndOp":
				if(iterator.hasNext()) nodeLeft =  iterator.next(); 
				else break;
				if(iterator.hasNext()) { 
					nodeRight =  iterator.next(); 
					node.element().setType(TypeSystem.boolOp(node.element().getLabel(), nodeLeft, nodeRight)); 
				}
				break;
			case"UminusOp":
				if(iterator.hasNext()) { 
					nodeLeft =  iterator.next(); 
					node.element().setType(TypeSystem.uMinusOp(nodeLeft)); 
				}
				break;
			case"CallOp":
				NodePositionList<Position<VisitableNode>> listNodeCall = new NodePositionList<Position<VisitableNode>>();
				NodePositionList<Position<VisitableNode>> listNodeFunc = new NodePositionList<Position<VisitableNode>>();
				String typeToReturn="";
				if(iterator.hasNext()) { 
					nodeLeft =  iterator.next(); 
					Token t = node.element().getTableOfSymbols().checkLessema(((IDNode) nodeLeft.element()).getValue());
					if(t == null) t = tree.root().element().getTableOfSymbols().checkLessema(((IDNode) nodeLeft.element()).getValue());
					if(t != null) {
						Position<VisitableNode> parent = tree.parent(t.getPositionNode());
						Iterator<Position<VisitableNode>> itPar  = tree.children(parent).iterator();
						Iterator<Position<VisitableNode>> itType;
						while(itPar.hasNext()) {
							Position<VisitableNode> child = itPar.next();
							if(child.element() instanceof ParDeclarationNode) {
								itType = tree.children(child).iterator();
								if(itType.hasNext()) typeToReturn += itType.next().element().getLabel()+"-";
								if(itType.hasNext()) {
									Position<VisitableNode> v = itType.next();
									listNodeFunc.addLast(v); 
									//System.out.println(((Leaf) v.element()).getValue());
								}
								if(itType.hasNext()) itType.next();
							}
						} 
						
					}
				}
				while(iterator.hasNext()) {
					Position<VisitableNode> v = iterator.next();
					listNodeCall.addLast(v); 
					//System.out.println(v.element().getType());
				}
				node.element().setType(TypeSystem.callOp(listNodeCall,listNodeFunc, typeToReturn)); 
				break;
			case"WriteOp":
			case"ReadOp":
				IONode IONode = null;
				if(node.element() instanceof IONode) IONode = (IONode) node.element();
				while(iterator.hasNext())
				{
					IONode.addTypeInList(iterator.next().element().getType());
				}
				break;
			default: break;
		}
	}
	
	public void valutateTypeLeafNode(Position<VisitableNode> node) {
		switch(node.element().getLabel()) {
			case "true":
			case "false": node.element().setType(TypeSystem.typeName[TypeSystem.BOOL]); break;
			case "int_const": node.element().setType(TypeSystem.typeName[TypeSystem.INT]); break;
			case "double_const": node.element().setType(TypeSystem.typeName[TypeSystem.DOUBLE]); break;
			case "string_const": node.element().setType(TypeSystem.typeName[TypeSystem.STRING]); break;
			//case "string_const": node.element().setType("string_const"); break;
			case "char_const": node.element().setType(TypeSystem.typeName[TypeSystem.CHAR]); break;
			default: break;
		}
	}
	
	
	public void evalutateTree(Position<VisitableNode> node) throws IdentifierNotDeclared, TypeMismatch {
		NodePositionList<Position<VisitableNode>> pos = new NodePositionList<Position<VisitableNode>>();
   	 	tree.postorderPositions(node, pos);
   	 	Iterator<Position<VisitableNode>> iterator = pos.iterator();
	 	while(iterator.hasNext()) {
	 	
	 		Position<VisitableNode> n = iterator.next();
	 		if(tree.isInternal(n)) {
	   	 		if(n.element() instanceof TypedNode) 
	   	 			valutateTypeInternalNode(n);
	 		}else if(n.element() instanceof ConstNode<?>) {
	 			valutateTypeLeafNode(n);
	 		}else if(n.element() instanceof UsageIDNode) {
	 			if(n.element().getSpecialType() != null) TypeSystem.checkUsageParFunction(n, tree.parent(n));
	 		}
	 	}
	}
	 	
	
}
