package Visitor;

import syntaxTree.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;

import stack.ArrayStack;
import support.IdentifierNotDeclared;
import support.TableArrayStack;
import support.TypeMismatch;
import tree.LinkedTree;
import tree.NodePositionList;
import tree.Position;
import wrapper.Body;
import wrapper.Call;
import wrapper.Compstat;
import wrapper.Constant;
import wrapper.Expression;
import wrapper.ExpressionBinary;
import wrapper.ExpressionUnary;
import wrapper.Identifier;
import wrapper.IfThen;
import wrapper.IfThenElse;
import wrapper.ParDeclaration;
import wrapper.ProcDeclaration;
import wrapper.Program;
import wrapper.Read;
import wrapper.SimpleExpression;
import wrapper.Statement;
import wrapper.VarAssign;
import wrapper.VarDeclaration;
import wrapper.VarInit;
import wrapper.While;
import wrapper.Write;

public class GenerationCSource {
	
	/*typedef int bool;
#define true 1
#define false 0*/
	
	private LinkedTree<VisitableNode> tree;
	private ArrayStack<String> stack;
	private String content = "";
	private String path;
	
	public GenerationCSource(LinkedTree<VisitableNode> tree, String path) {
		this.tree = tree;
		this.path=path;
	}
	

	
	public String getContent() {
		return this.content;
	}
	
	public void evalutateTree(Position<VisitableNode> node)  {
   	 	if(tree.isRoot(node)) content = valutateProgram(node).generateCode();
	}
	
	private Program valutateProgram(Position<VisitableNode> node) {
		Program p = new Program();
		Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
		while(it.hasNext()) {
			Position<VisitableNode> child = it.next();
			if(tree.isInternal(child)) {
	 			if(child.element() instanceof VarDeclarationNode) {
	 				p.addVarDeclaration(valuteVarDeclaration(child));
	 			}
	 			if(child.element() instanceof FuncDeclarationNode) {
	 				p.addProcDeclaration(valutateFuncDeclarationNode(child));
	 			}
	 			if(child.element() instanceof TypedNode
	 					&& !(child.element() instanceof ExpressionNode) ) {
	 				p.addStatement(valutateStatement(child));
	 			}
	 		}
		}
		return p;
	}
	
	private ProcDeclaration valutateFuncDeclarationNode(Position<VisitableNode> node) {
		
		Identifier identifier=null;
		Body body = null;
		VarInit varInit;
		
		Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
		
		if(it.hasNext()) {
			VisitableNode id = it.next().element();
			identifier = new Identifier(((DeclarationIDNode<String>)id).getValue());
			if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
		}
		
		ProcDeclaration p = new ProcDeclaration(identifier);

		while(it.hasNext()) {
			Position<VisitableNode> child = it.next();	
			if(child.element() instanceof ParDeclarationNode) {
				p.addDeclaration(valutateParDeclaration(child));
			}
				
			else if(child.element() instanceof VisitableNode)
				body = valutateBody(child);
		}
		p.setBody(body);
		return p;
	}
	
	private ParDeclaration valutateParDeclaration(Position<VisitableNode> node) {
		String typePar=null;
		String type=null;
		Identifier identifier=null;
	
		if(tree.isInternal(node)) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator(); 
			if(it.hasNext()) typePar = ((Leaf<String>) it.next().element()).getLabel();
			if(it.hasNext()) type = ((Leaf<String>) it.next().element()).getValue();
			if(it.hasNext()) {
				VisitableNode id = it.next().element();
				identifier = new Identifier(((IDNode<String>)id).getValue());
				identifier.setSpecialType(typePar);
			}
		}

		return new ParDeclaration(typePar, type, identifier);
	}
	
	private Body valutateBody(Position<VisitableNode> node) {
		Body b = new Body();
		Iterator<Position<VisitableNode>> it = tree.children(node).iterator(); 
		while(it.hasNext()) {
			Position<VisitableNode> child = it.next();	
			if(child.element() instanceof VarDeclarationNode) 
				b.addVarDeclaration(valuteVarDeclaration(child));
			else if(child.element() instanceof TypedNode
 					&& !(child.element() instanceof ExpressionNode) )
 				b.addStatement(valutateStatement(child));	
		}
		return b;
	}
	private VarDeclaration valuteVarDeclaration(Position<VisitableNode> node) {
		VarDeclaration varDecl=null;
		VarInit varInit;
		
		Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
		if(it.hasNext()) varDecl = new VarDeclaration(((Leaf<String>) it.next().element()).getValue()); //type

		while(it.hasNext()) {
			varInit = valutateVarInit(it.next());
			varDecl.addDeclaration(varInit);
		}
		
		return varDecl;
	}
	
	private VarInit valutateVarInit(Position<VisitableNode> node) {
		Expression expression = null;
		Identifier identifier= null;
		
		if(tree.isInternal(node)) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator(); 
			while(it.hasNext()) {
				Position<VisitableNode> child = it.next();	
				if(child.element() instanceof DeclarationIDNode) {
					VisitableNode id = child.element();
					identifier = new Identifier(((DeclarationIDNode<String>)id).getValue());
					if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
				}
				else if(child.element() instanceof ExpressionNode || 
						child.element() instanceof ConstNode || 
						child.element() instanceof UsageIDNode) 
					expression = valutateExpression(child);
				else 
					expression = null;
			}
		}
		return new VarInit(identifier, expression);
	}
	
	private VarAssign valutateVarAssign(Position<VisitableNode> node) {
		Expression expression = null;
		Identifier identifier=null;
		
		if(tree.isInternal(node)) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator(); 
			if(it.hasNext()) {
				Position<VisitableNode> child = it.next();	
				if(child.element() instanceof UsageIDNode) {
					VisitableNode id = child.element();
					identifier = new Identifier(((UsageIDNode<String>)id).getValue());
					if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
				}
			}

			while(it.hasNext()) {
				Position<VisitableNode> child = it.next();	
				if(child.element() instanceof ExpressionNode || 
						child.element() instanceof ConstNode || child.element() instanceof UsageIDNode) 
					expression = valutateExpression(child);
				else 
					expression = null;
			}
		}
		return new VarAssign(identifier, expression);
	}
	

	private While valutateWhile(Position<VisitableNode> node) {
		Expression expr = null;
		Compstat thenComp = null;
		
		if(node.element() instanceof TypedNode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			Position<VisitableNode> condition = null;
			Position<VisitableNode> thenStat = null;
			if(it.hasNext()) condition = it.next();
			if(it.hasNext()) thenStat = it.next();
			
			if(condition != null) 
				expr = valutateExpression(condition);
			if(thenStat != null)
				thenComp = valutateCompstat(thenStat);
		}
		return new While(expr, thenComp);
	}
	
	private IfThen valutateIfThen(Position<VisitableNode> node) {
		Expression expr = null;
		Compstat thenComp = null;
		
		if(node.element() instanceof TypedNode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			Position<VisitableNode> condition = null;
			Position<VisitableNode> thenStat = null;
			if(it.hasNext()) condition = it.next();
			if(it.hasNext()) thenStat = it.next();
			
			if(condition != null) 
				expr = valutateExpression(condition);
			if(thenStat != null)
				thenComp = valutateCompstat(thenStat);
		}
		return new IfThen(expr, thenComp);
	}
	
	private IfThenElse valutateIfThenElse(Position<VisitableNode> node) {
		Expression expr = null;
		Compstat thenComp = null;
		Compstat elseComp = null;
		
		if(node.element() instanceof TypedNode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			Position<VisitableNode> condition = null;
			Position<VisitableNode> thenStat = null;
			Position<VisitableNode> elseStat = null;
			if(it.hasNext()) condition = it.next();
			if(it.hasNext()) thenStat = it.next();
			if(it.hasNext()) elseStat = it.next();
			
			if(condition != null) 
				expr = valutateExpression(condition);
			if(thenStat != null)
				thenComp = valutateCompstat(thenStat);
			if(elseStat != null)
				elseComp = valutateCompstat(elseStat);
		}
		return new IfThenElse(expr, thenComp, elseComp);
	}
	
	private Call valutateCall(Position<VisitableNode> node) {
		Identifier identifier = null;
		Call call=null;
		if(node.element() instanceof TypedNode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			if(it.hasNext()) {
				VisitableNode id = it.next().element();
				identifier = new Identifier(((UsageIDNode<String>)id).getValue());
				if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
			}
			
			call = new Call(identifier);
			while(it.hasNext()) {
				call.addExpression(valutateExpression(it.next()));
			}
		}
		call.setType(node.element().getType().substring(0, node.element().getType().length()-1));
		return call;
	}
	
	private Read valutateRead(Position<VisitableNode> node) {
		Read read= new Read();
		if(node.element() instanceof IONode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			while(it.hasNext()) {
				VisitableNode id = it.next().element();
				Identifier identifier = new Identifier(((UsageIDNode<String>)id).getValue());
				if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
				read.addID(identifier);
			}
		}
		read.setType(node.element().getType());
		return read;
	}
	
	private Write valutateWrite(Position<VisitableNode> node) {
		Write write= new Write();
		if(node.element() instanceof IONode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			while(it.hasNext()) {
				write.addExpression(valutateExpression(it.next()));
			}
		}
		write.setType(node.element().getType());
		return write;
	}
	
	private Statement valutateStatement(Position<VisitableNode> node) {
		Statement stat = null;
			switch(node.element().getLabel()){
			case "WhileOp": stat = valutateWhile(node); break;
			case "IfThenElseOp": stat = valutateIfThenElse(node); break;
			case "IfThenOp": stat = valutateIfThen(node); break;
			case "AssignOp": stat = valutateVarAssign(node); break;
			case "CallOp": stat = valutateCall(node); break;
			case "ReadOp": stat = valutateRead(node); break;
			case "WriteOp": stat = valutateWrite(node); break;
			default:break;
			}
		
		return stat;
	}
	
	private Compstat valutateCompstat(Position<VisitableNode> node) {
		Compstat c = new Compstat();
		if(tree.isInternal(node)) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator(); 
			while(it.hasNext()) {
				c.addStatement(valutateStatement(it.next()));
			}
		}
		return c;
	}
	
	private Expression valutateSimpleExpression(Position<VisitableNode> node) {
		if(node.element() instanceof ConstNode) {
			Constant c = new Constant(""+((ConstNode)node.element()).getValue(), node.element().getType());
			return new SimpleExpression(c);
		}else if(node.element() instanceof UsageIDNode) {
			VisitableNode id = node.element();
			Identifier identifier = new Identifier(((UsageIDNode<String>)id).getValue());
			if(id.getSpecialType() != null) identifier.setSpecialType(id.getSpecialType());
			return new SimpleExpression(identifier);
	 	}
		return null;
	}
	
	private Expression valutateCompExpression(Position<VisitableNode> node) {
		if(node.element() instanceof ExpressionNode) {
			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
			Position<VisitableNode> leftChild = null;
			Position<VisitableNode> rightChild = null;
			if(it.hasNext()) leftChild = it.next();
			if(it.hasNext()) rightChild = it.next();
			
			if(rightChild == null) {
				return new ExpressionUnary(((ExpressionNode) node.element()).getLabel(), valutateExpression(leftChild));
			}else {
				return new ExpressionBinary(((ExpressionNode) node.element()).getLabel(), valutateExpression(leftChild),valutateExpression(rightChild) );
			}
		}
		return null;
	}
	
	private Expression valutateExpression(Position<VisitableNode> node) {
		Expression expr = null;
		 if(node.element() instanceof ExpressionNode)
			 expr = valutateCompExpression(node);
		 else
			 expr = valutateSimpleExpression(node);
		 return expr;
	}
	
	public void saveFile(){
        Writer writer = null;
        try {
        	final File file = new File(path);
        	file.setReadable(true, false);
        	file.setExecutable(true, false);
        	file.setWritable(true, false);
            writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(file)));
            writer.write(this.content);
            writer.close();
        } catch (IOException ex) {
            System.out.println("Errore nella scrittura del file");
        } finally {
            try {writer.close();} catch (Exception ex) {
                System.out.println("Errore durante la chiusura del file");
            }
        }
    }
}
