package Visitor;

import syntaxTree.*;
import java.util.ArrayList;
import java.util.Iterator;

import support.IdentifierNotDeclared;
import support.MultipleDeclarationException;
import support.TableArrayStack;
import support.TableOfSymbols;
import support.Token;
import tree.LinkedTree;
import tree.NodePositionList;
import tree.Position;
import tree.TreeNode;

public class ScopingTree {
	
	private TableArrayStack stack;
	private LinkedTree<VisitableNode> tree;
	private ArrayList<TableOfSymbols> arrayTb;
	
	public ScopingTree(LinkedTree<VisitableNode> tree) {
		this.tree = tree;
		stack = new TableArrayStack();
		arrayTb = new ArrayList<TableOfSymbols>();
	}
	
	
	
	public void setVarDeclarationType(Position<VisitableNode> node) {
		 Iterator<Position<VisitableNode>> it =  tree.children(node).iterator();
		 String type = null;
		 if(it.hasNext()) { 
			 VisitableNode typeNode = it.next().element();
			 if(typeNode instanceof Leaf)
			 type = ((Leaf<String>)typeNode).getValue();
		 }
		 
		 while(it.hasNext()) {
			 Position<VisitableNode> initChild = it.next();
			 if(tree.isInternal(initChild)) {
				 Iterator<Position<VisitableNode>> it2 = tree.children(initChild).iterator();
				 while(it2.hasNext()) {
					 VisitableNode child = it2.next().element();
					 if(child instanceof DeclarationIDNode) {
						 child.setType(type);
					 }
				 }
			 } 	
		 }
	}
	
	public void setParDeclarationType(Position<VisitableNode> node) {
		 Iterator<Position<VisitableNode>> it =  tree.children(node).iterator();
		 while(it.hasNext()) {
			 String typePar = null;
			 String typeID = null;
			 typePar = it.next().element().getLabel();
			 //Position<VisitableNode> typeNode;
			 //Position<VisitableNode> IDNode;
			 if(it.hasNext()) { 
				 VisitableNode typeNode = it.next().element();
				 if(typeNode instanceof Leaf)
				 typeID = ((Leaf<String>)typeNode).getValue();
			 }
			 if(it.hasNext()) {
					 VisitableNode child = it.next().element();
					 if(child instanceof DeclarationIDNode) {
						 child.setType(typeID);
						 child.setSpecialType(typePar);
					 }
				 }
			 } 	
		 }
	

	
	public void checkUsageIDAndType(Position<VisitableNode> n) throws IdentifierNotDeclared {
		if(n.element() instanceof UsageIDNode) {
			UsageIDNode<String> usageNode = (UsageIDNode<String>) n.element();
			Token t = stack.lookup(usageNode.getValue());
			if(t == null) throw new IdentifierNotDeclared(usageNode.getValue());
			n.element().setType(t.getNode().getType());
			n.element().setSpecialType(t.getNode().getSpecialType());
			//if(t.getNode().getSpecialType() != null) checkUsageParFunction(n);
		}
	}

	
	public void createScopingTables(Position<VisitableNode> node) throws MultipleDeclarationException, IdentifierNotDeclared {
	    if (tree.isInternal(node)) {
	    	if(node.element() instanceof ScopingNode) {
	    		switch(node.element().getLabel()) {
	    		case "ProgramOp":
	    			stack.enterScope(new TableOfSymbols());
	    			node.element().setTableOfSymbols(stack.getCurrentScope());
	    			checkUsageIDAndType(node);
	    			for (Position<VisitableNode> w : tree.children(node))
		 				createScopingTables(w);	// recurse on each child
	    			stack.exitScope();
	    			break;
	    		case "ProcDeclOp":
	    			Iterator<Position<VisitableNode>> it = tree.children(node).iterator();
	    			Position<VisitableNode> procNameChild = null; 
	    			if(it.hasNext()) {
	    				procNameChild = it.next();
	    				if(procNameChild.element() instanceof DeclarationIDNode){
	    					DeclarationIDNode l = (DeclarationIDNode) procNameChild.element();
	    		 			if(l.getValue() != null) {
	    		 				l.setType("func");
	    		 				stack.addId("ID",l.getValue().toString()); //exception
	    		 				stack.getCurrentScope().checkLessema(l.getValue().toString()).setNode(procNameChild);
	    		 			}
	    				}
	    			}
	    			if(procNameChild != null)procNameChild.element().setTableOfSymbols(stack.getCurrentScope());
	    			stack.enterScope(new TableOfSymbols());
	    			node.element().setTableOfSymbols(stack.getCurrentScope());
	    			checkUsageIDAndType(node);
	    			while (it.hasNext()) {
	    				createScopingTables(it.next());	// recurse on each child
	    			}
	    			stack.exitScope();
	    			break;
	    		default: break;
	    		}
	 		}else {
	 			if(node.element() instanceof VarDeclarationNode) setVarDeclarationType(node);
	 			if(node.element() instanceof ParDeclarationNode) setParDeclarationType(node);
	 			node.element().setTableOfSymbols(stack.getCurrentScope());
	 			checkUsageIDAndType(node);
	 			if(node.element() instanceof ParDeclarationNode) setParDeclarationType(node);
	 			for (Position<VisitableNode> w : tree.children(node))
	 				createScopingTables(w);	// recurse on each child
	 		}
	    }else {
	    	if(node.element() instanceof DeclarationIDNode){
	    		DeclarationIDNode l = (DeclarationIDNode) node.element();
	 			if(l.getValue() != null) {
	 				stack.addId("ID",l.getValue().toString()); //exception
	 				stack.getCurrentScope().checkLessema(l.getValue().toString()).setNode(node);
	 			}	
	 			node.element().setTableOfSymbols(stack.getCurrentScope());
	 			checkUsageIDAndType(node);
	 		}else {
	 			node.element().setTableOfSymbols(stack.getCurrentScope());
	 			checkUsageIDAndType(node);
	 		}
	    }
	}
	
	public void printScopingTables() {
		NodePositionList<Position<VisitableNode>> pos = new NodePositionList<Position<VisitableNode>>();
   	 	tree.preorderPositions(tree.root(), pos);
   	 	Iterator<Position<VisitableNode>> iter = pos.iterator();
   	 	while (iter.hasNext()) {
   	 		Position<VisitableNode> n = iter.next();
   	 		if(n.element() instanceof ScopingNode) {
   	 			System.out.println("**********************"+n.element().getLabel()+"*********************");
   	 			n.element().getTableOfSymbols().printTable();
   	 			System.out.println("****************************************************");
   	 		}
   	 	}
   	 }
}
