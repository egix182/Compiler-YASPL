package Visitor;


import java.util.Iterator;
import syntaxTree.*;
import tree.LinkedTree;
import tree.NodePositionList;
import tree.Position;

public class ExprTree {
	
	LinkedTree<VisitableNode> tree;
	
	public ExprTree(LinkedTree<VisitableNode> tree) {
		this.tree = tree;
	}
	

	public double getValue(Position<VisitableNode> node) {
		if(node.element() instanceof ConstNode) {
			switch(node.element().getLabel()) {
			case "int_const": return (double)((ConstNode<Integer>)node.element()).getValue();
			case "double_const": return (double)((ConstNode<Double>)node.element()).getValue();
			default: return 0;
			}
		}
		else if(node.element() instanceof ExpressionNode<?>)
			return (double) ((ExpressionNode<Number>)node.element()).getValue().doubleValue();
		
		return 0;
	}
	
	public double getValueNode(Position<VisitableNode> node) {
		return (double)((ExpressionNode<Number>)node.element()).getValue();
	}
	
	public void valutateExpr(Position<VisitableNode> node) {
		Iterable<Position<VisitableNode>> it = tree.children(node);
		Iterator<Position<VisitableNode>> iterator = it.iterator();
		ExpressionNode<Number> nodeNumber;
		switch(node.element().getLabel()) {
		case "AddOp":
			nodeNumber = (ExpressionNode<Number>) node.element();
			while(iterator.hasNext()) {
				Position<VisitableNode> figlio =  iterator.next();
				if(figlio.element() instanceof Leaf || figlio.element() instanceof ExpressionNode<?>) {
					Number n = nodeNumber.getValue();
					if(n != null)
						nodeNumber.setValue(nodeNumber.getValue().doubleValue() + getValue(figlio));
					else
						nodeNumber.setValue(getValue(figlio));
				}
			}
			break;
		case "DiffOp":
			nodeNumber = (ExpressionNode<Number>) node.element();
			while(iterator.hasNext()) {
				Position<VisitableNode> figlio =  iterator.next();
				if(figlio.element() instanceof Leaf || figlio.element() instanceof ExpressionNode<?>) {
					Number n = nodeNumber.getValue();
					if(n != null)
						nodeNumber.setValue(nodeNumber.getValue().doubleValue() - getValue(figlio));
					else
						nodeNumber.setValue(getValue(figlio));
				}
			}
			break;
		case "MulOp":
			nodeNumber = (ExpressionNode<Number>) node.element();
			while(iterator.hasNext()) {
				Position<VisitableNode> figlio =  iterator.next();
				if(figlio.element() instanceof Leaf || figlio.element() instanceof ExpressionNode<?>) {
					Number n = nodeNumber.getValue();
					if(n != null)
						nodeNumber.setValue(nodeNumber.getValue().doubleValue() * getValue(figlio));
					else
						nodeNumber.setValue(getValue(figlio));
				}
			}
			break;
		case "DivOp":
			nodeNumber = (ExpressionNode<Number>) node.element();
			while(iterator.hasNext()) {
				Position<VisitableNode> figlio =  iterator.next();
				if(figlio.element() instanceof Leaf || figlio.element() instanceof ExpressionNode<?>) {
					Number n = nodeNumber.getValue();
					if(n != null)
						nodeNumber.setValue(nodeNumber.getValue().doubleValue() / getValue(figlio));
					else
						nodeNumber.setValue(getValue(figlio));
				}
			}
			break;
		default: break;
	}
	}
	
	public void evalutateTree(Position<VisitableNode> node) {
		NodePositionList<Position<VisitableNode>> pos = new NodePositionList<Position<VisitableNode>>();
   	 	tree.postorderPositions(node, pos);
   	 	Iterator<Position<VisitableNode>> iterator = pos.iterator();
	 	while(iterator.hasNext()) {
	 		Position<VisitableNode> n = iterator.next();
	 		if(n.element() instanceof ExpressionNode<?>) {
	 			valutateExpr(n);
	 		}
	 	}
	}
		

}
