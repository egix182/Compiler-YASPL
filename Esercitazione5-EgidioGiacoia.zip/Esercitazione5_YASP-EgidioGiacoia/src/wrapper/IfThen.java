package wrapper;

public class IfThen extends Statement{

	private Expression expr;
	private Compstat compstat;
	
	public IfThen(Expression expr, Compstat compstat) {
		this.expr = expr;
		this.compstat = compstat;
	}
	
	@Override
	public String generateCode() {
		return "if( "+expr.generateCode()+" )"+compstat.generateCode();
	}
}
