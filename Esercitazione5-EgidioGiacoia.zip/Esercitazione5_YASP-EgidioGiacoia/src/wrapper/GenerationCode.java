package wrapper;

public interface GenerationCode {
	public String generateCode();
}
