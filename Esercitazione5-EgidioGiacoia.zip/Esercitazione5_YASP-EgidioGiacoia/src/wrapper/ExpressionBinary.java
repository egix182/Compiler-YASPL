package wrapper;

public class ExpressionBinary extends Expression {

	private String operation;
	private Expression leftExpr;
	private Expression rightExpr;
	
	public ExpressionBinary(String operation, Expression leftExpr, Expression rightExpr) {
		this.operation = operation;
		this.leftExpr = leftExpr;
		this.rightExpr = rightExpr;
	}

	public Expression getLeftExpr() {
		return leftExpr;
	}

	public void setLeftExpr(Expression leftExpr) {
		this.leftExpr = leftExpr;
	}

	public Expression getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(Expression rightExpr) {
		this.rightExpr = rightExpr;
	}
	
	
	private String checkOperation() {
		switch(operation) {
		case"AddOp": return "+"; 
		case"DiffOp": return "-";
		case"MulOp": return "*";
		case"DivOp": return "/";
		case"AndOp": return "&&";
		case"OrOp": return "||";
		case"GTOp": return ">";
		case"GEOp": return ">=";
		case"LTOp": return "<";
		case"LEOp": return "<=";
		case"EQOp": return "==";
		default: return "";
		}
	}
	
	@Override
	public String generateCode() {
		return leftExpr.generateCode() +" "+checkOperation()+" "+rightExpr.generateCode()+"";
	}
}
