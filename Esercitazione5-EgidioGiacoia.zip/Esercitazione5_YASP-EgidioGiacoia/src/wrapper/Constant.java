package wrapper;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;


public class Constant {
	
	private String constant;
	private String type;
	
	public Constant(String constant, String type) {
		this.constant = StringEscapeUtils.escapeJava(constant);
		this.type = type;
	}
	
	private String checkConstant() {
		switch(type) {
		case"string": return "\""+constant+"\"";
		case"char": return "\'"+constant+"\'";
		default: return constant;
		}
	}
	public String generateCode() {
		return checkConstant();
	}
}
