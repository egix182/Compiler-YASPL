package wrapper;

public class Identifier {
	private String identifier;
	private String typePar;
	
	public Identifier(String identifier) {
		this.identifier = identifier;
		this.typePar = null;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getSpecialType() {
		return typePar;
	}

	public void setSpecialType(String typePar) {
		this.typePar = typePar;
	}
	
	private String checkParType() {
		if(typePar != null) {
			switch(typePar) {
			case"INOUT": return "*"+identifier;
			case"OUT": return "*"+identifier;
			case"IN": return identifier;
			default: return identifier;
			}
		}
		return identifier;
	}
	
	public String generateCode() {
		return checkParType();
	}
}
