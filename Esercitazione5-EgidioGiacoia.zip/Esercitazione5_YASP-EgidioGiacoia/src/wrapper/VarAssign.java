package wrapper;

import java.util.ArrayList;

public class VarAssign extends Statement{
	
	private Identifier identifier;
	private ArrayList<Expression> arrayExpr;
	private Expression expression;
	
	public VarAssign(Identifier identifier) {
		this.identifier = identifier;
		this.arrayExpr = new ArrayList<Expression>();
	}
	
	public VarAssign(Identifier identifier, Expression expression) {
		this.identifier = identifier;
		this.expression = expression;
	}

	public Identifier getIdentifier() {
		return identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

	public void addDeclaration(Expression v) {
		arrayExpr.add(v);
	}
	
	public ArrayList<Expression> getArrayExpr() {
		return arrayExpr;
	}

	public void setArrayExpr(ArrayList<Expression> arrayExpr) {
		this.arrayExpr = arrayExpr;
	}
	
	

	public Expression getExpression() {
		return expression;
	}

	public void setExpression(Expression expression) {
		this.expression = expression;
	}

	public String generateCode() {
		if(getExpression() == null) return getIdentifier().generateCode();
		return getIdentifier().generateCode() +" = "+getExpression().generateCode()+";";
	}
}
