package wrapper;

public class While extends Statement{

	private Expression expr;
	private Compstat compstat;
	
	public While(Expression expr, Compstat compstat) {
		this.expr = expr;
		this.compstat = compstat;
	}
	
	@Override
	public String generateCode() {
		return "while( "+expr.generateCode()+" )"+compstat.generateCode();
	}
}
