package wrapper;

import java.util.ArrayList;

public class Program {
	
	private ArrayList<VarDeclaration> arrayVarDeclaration;
	private ArrayList<ProcDeclaration> arrayProcDeclaration;
	private ArrayList<Statement> arrayStat;
	
	public Program() {
		arrayVarDeclaration = new ArrayList<VarDeclaration>();
		arrayStat = new ArrayList<Statement>();
		arrayProcDeclaration = new ArrayList<ProcDeclaration>();
	}
	
	public void addVarDeclaration(VarDeclaration varDeclaration) {
		arrayVarDeclaration.add(varDeclaration);
	}
	
	public void addProcDeclaration(ProcDeclaration procDeclaration) {
		arrayProcDeclaration.add(procDeclaration);
	}
	
	public void addStatement(Statement statement) {
		arrayStat.add(statement);
	}
	

	
	public String generateCode() {
		String toReturn="#include <stdio.h> \r\n"
				+ "typedef int bool;\r\n" + 
				"#define true 1\r\n" + 
				"#define false 0 \r\n";
		for(ProcDeclaration d : arrayProcDeclaration) {
			toReturn += d.generateCode()+"\r\n";
		}
		toReturn += "int main(void){\r\n";
		for(VarDeclaration d : arrayVarDeclaration) {
			toReturn += d.generateCode()+"\r\n";
		}
		for(Statement s : arrayStat) {
			toReturn += s.generateCode()+"\r\n";
		}
		toReturn += "}";
		return toReturn;
	}

}
