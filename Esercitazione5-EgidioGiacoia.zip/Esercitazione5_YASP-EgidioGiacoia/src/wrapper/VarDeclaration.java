package wrapper;

import java.util.ArrayList;

public class VarDeclaration {
	
	private ArrayList<VarInit> arrayDeclaration;
	private String type;
	
	public VarDeclaration(String type) {
		this.type = type;
		arrayDeclaration = new ArrayList<VarInit>();
	}
	
	public void addDeclaration(VarInit v) {
		arrayDeclaration.add(v);
	}
	
	public ArrayList<VarInit> getArrayDeclaration() {
		return arrayDeclaration;
	}


	public void setArrayDeclaration(ArrayList<VarInit> arrayDeclaration) {
		this.arrayDeclaration = arrayDeclaration;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	private String checkType() {
		switch(type) {
		case"bool": return "int";
		default: return type;
		}
	}
	
	public String generateCode() {
		String toReturn="";
		for(VarInit vi : arrayDeclaration) {
			toReturn += checkType() + " "+vi.generateCode()+";\r\n";
		}
		return toReturn;
	}
}
