package wrapper;

public class SimpleExpression extends Expression{

	private Identifier identifier;
	private Constant constant;
	
	public SimpleExpression(Identifier identifier) {
		super();
		this.identifier = identifier;
	}
	
	public SimpleExpression(Constant constant) {
		super();
		this.constant = constant;
	}
	
	
	public Identifier getIdentifier() {
		return identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

	public Constant getConstant() {
		return constant;
	}

	public void setConstant(Constant constant) {
		this.constant = constant;
	}

	@Override
	public String generateCode() {
		if(getConstant() != null) return getConstant().generateCode();
		return getIdentifier().generateCode();
	}
}
