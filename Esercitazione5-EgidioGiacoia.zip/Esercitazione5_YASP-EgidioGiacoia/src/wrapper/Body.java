package wrapper;

import java.util.ArrayList;

public class Body {
	
	private ArrayList<VarDeclaration> arrayDeclaration;
	private ArrayList<Statement> arrayStat;

	
	public Body() {
		arrayDeclaration = new ArrayList<VarDeclaration>();
		arrayStat = new ArrayList<Statement>();
	}
	
	public void addVarDeclaration(VarDeclaration varDeclaration) {
		arrayDeclaration.add(varDeclaration);
	}
	
	public void addStatement(Statement statement) {
		arrayStat.add(statement);
	}
	
	
	
	public String generateCode() {
		String toReturn="";
		for(VarDeclaration d : arrayDeclaration) {
			toReturn += d.generateCode()+"\r\n";
		}
		for(Statement s : arrayStat) {
			toReturn += s.generateCode()+"\r\n";
		}
		return toReturn;
	}

}
