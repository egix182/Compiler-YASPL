package wrapper;

public class ParDeclaration {
	
	private String typePar;
	private String type;
	private Identifier identifier;
	
	public ParDeclaration(String typePar, String type, Identifier identifier) {
		this.typePar = typePar;
		this.type = type;
		this.identifier = identifier;
	}

	public String getTypePar() {
		return typePar;
	}

	public void setTypePar(String typePar) {
		this.typePar = typePar;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Identifier getIdentifier() {
		return identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

	/*private String checkPar() {
		switch(typePar) {
		case"INOUT":
		case"OUT": return type+"*";
		case"IN": return type;
		default: return type;
		}
	}*/
	
	public String generateCode() {
		//return checkPar() +" "+identifier.generateCode();
		return type +" "+ identifier.generateCode();
	}
}
