package wrapper;

import java.util.ArrayList;

public class Write extends Statement{

	private ArrayList<Expression> arrayExpr;
	private String type;
	
	public Write() {
		this.arrayExpr = new ArrayList<Expression>();
	}
	
	public void addExpression(Expression e) {
		arrayExpr.add(e);
	}
	
	
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	public ArrayList<Expression> getArrayID() {
		return arrayExpr;
	}

	public void setArrayExpr(ArrayList<Expression> arrayExpr) {
		this.arrayExpr = arrayExpr;
	}

	private String checkPassValue(int index) {
		String[] parts = type.split("-");
		switch(parts[index]) {
		case"int": return "\"%d\"";
		case"double": return "\"%lf\"";
		case"char": return "\"%c\"";
		case"string": return "\"%s\"";
		case"bool": return "\"%d\"";
		//case"string_const": return "";
		//case"char_const": return "";
		default: return "";
		}
	}
	
	@Override
	public String generateCode() {
		String toReturn="";
		for(int i=0; i<arrayExpr.size(); i++) {
			//if(checkPassValue(i).equals("")) toReturn += "fprintf(stdin , \""+arrayExpr.get(i).generateCode()+"\");\r\n";
			//else toReturn += "fprintf(stdin , " +checkPassValue(i)+", "+arrayExpr.get(i).generateCode()+");\r\n";
			 toReturn += "fprintf(stdout," +checkPassValue(i)+", "+arrayExpr.get(i).generateCode()+"); \r\n";
		}
		return toReturn;
	}
}
