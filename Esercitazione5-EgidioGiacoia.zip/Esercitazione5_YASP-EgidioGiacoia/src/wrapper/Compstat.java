package wrapper;

import java.util.ArrayList;

public class Compstat {
	private ArrayList<Statement> arrayStat;
	
	public Compstat() {
		arrayStat = new ArrayList<Statement>();
	}
	
	public void addStatement(Statement s) {
		arrayStat.add(s);
	}
	
	public String generateCode() {
		String toReturn="{\r\n";
		for(Statement s : arrayStat) {
			toReturn += s.generateCode()+"\r\n";
		}
		toReturn+="}\r\n";
		return toReturn;
	}
}
