package wrapper;

public class ExpressionUnary extends Expression {

	private String operation;
	private Expression leftExpr;
	
	public ExpressionUnary(String operation, Expression leftExpr) {
		this.operation = operation;
		this.leftExpr = leftExpr;
	}

	public Expression getLeftExpr() {
		return leftExpr;
	}

	public void setLeftExpr(Expression leftExpr) {
		this.leftExpr = leftExpr;
	}

	
	private String checkOperation() {
		switch(operation) {
		case"UminusOp": return "-";
		case"NotOp": return "!";
		default: return "";
		}
	}
	
	@Override
	public String generateCode() {
		return checkOperation()+"("+leftExpr.generateCode()+")";
	}
}
