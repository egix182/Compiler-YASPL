package wrapper;

import java.util.ArrayList;

public class ProcDeclaration {
	
	private ArrayList<ParDeclaration> arrayDeclaration;
	private Identifier identifier;
	private Body body;
	
	public ProcDeclaration(Identifier identifier) {
		this.identifier = identifier;
		arrayDeclaration = new ArrayList<ParDeclaration>();
		this.body = null;
	}
	
	public ProcDeclaration(Identifier identifier, Body body) {
		this.identifier = identifier;
		arrayDeclaration = new ArrayList<ParDeclaration>();
		this.body = body;
	}
	
	public void addDeclaration(ParDeclaration v) {
		arrayDeclaration.add(v);
	}
	
	public ArrayList<ParDeclaration> getArrayDeclaration() {
		return arrayDeclaration;
	}


	public void setArrayDeclaration(ArrayList<ParDeclaration> arrayDeclaration) {
		this.arrayDeclaration = arrayDeclaration;
	}


	
	public Identifier getIdentifier() {
		return identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

	public Body getBody() {
		return body;
	}

	public void setBody(Body body) {
		this.body = body;
	}

	public String generateCode() {
		String toReturn="void "+identifier.generateCode()+"(";
		
		for(int i=0; i<arrayDeclaration.size(); i++) {
			toReturn += arrayDeclaration.get(i).generateCode();
			if(i != arrayDeclaration.size()-1) toReturn +=" , ";
		}
		toReturn+="){\r\n";
		toReturn += body.generateCode();
		toReturn+="}\r\n";
		return toReturn;
	}
}
