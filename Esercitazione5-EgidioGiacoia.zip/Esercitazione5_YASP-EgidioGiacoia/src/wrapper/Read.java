package wrapper;

import java.util.ArrayList;

public class Read extends Statement{

	private ArrayList<Identifier> arrayID;
	private String type;
	
	public Read() {
		this.arrayID = new ArrayList<Identifier>();
	}
	
	public void addID(Identifier id) {
		arrayID.add(id);
	}
	
	
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	public ArrayList<Identifier> getArrayID() {
		return arrayID;
	}

	public void setArrayExpr(ArrayList<Identifier> arrayID) {
		this.arrayID = arrayID;
	}

	private String checkPassValue(int index) {
		String[] parts = type.split("-");
		switch(parts[index]) {
		case"int": return "%d";
		case"double": return "%lf";
		case"char": return "%c";
		case"string": return "%s";
		default: return "";
		}
	}
	
	@Override
	public String generateCode() {
		String toReturn="";
		for(int i=0; i<arrayID.size(); i++) {
			toReturn += "scanf(\""+checkPassValue(i)+"\", &"+arrayID.get(i).generateCode()+");\r\n";
		}
		return toReturn;
	}
}
