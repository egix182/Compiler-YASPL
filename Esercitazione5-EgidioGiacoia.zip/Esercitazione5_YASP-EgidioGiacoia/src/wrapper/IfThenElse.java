package wrapper;

public class IfThenElse extends Statement{

	private Expression expr;
	private Compstat compstatThen;
	private Compstat compstatElse;
	
	public IfThenElse(Expression expr, Compstat compstatThen, Compstat compstatElse) {
		this.expr = expr;
		this.compstatThen = compstatThen;
		this.compstatElse = compstatElse;
	}
	
	@Override
	public String generateCode() {
		return "if( "+expr.generateCode()+" )"+compstatThen.generateCode()+"else"+ compstatElse.generateCode();
	}
}
