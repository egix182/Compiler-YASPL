package wrapper;

import java.util.ArrayList;

public class Call extends Statement{

	private Identifier identifier;
	private ArrayList<Expression> arrayExpr;
	private String type;
	
	public Call(Identifier identifier) {
		this.identifier = identifier;
		this.arrayExpr = new ArrayList<Expression>();
	}
	
	public void addExpression(Expression e) {
		arrayExpr.add(e);
	}
	
	
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Identifier getIdentifier() {
		return identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

	public ArrayList<Expression> getArrayExpr() {
		return arrayExpr;
	}

	public void setArrayExpr(ArrayList<Expression> arrayExpr) {
		this.arrayExpr = arrayExpr;
	}

	private String checkPassValue(int index) {
		String[] parts = type.split("-");
		switch(parts[index]) {
		case"IN": return "";
		case"INOUT": return "&";
		case"OUT": return "&";
		default: return "";
		}
	}
	
	@Override
	public String generateCode() {
		String toReturn = identifier.generateCode()+"(";
		for(int i=0; i<arrayExpr.size(); i++) {
			toReturn += checkPassValue(i)+arrayExpr.get(i).generateCode();
			if(i != arrayExpr.size()-1) toReturn +=" , ";
		}
		return toReturn +");";
	}
}
