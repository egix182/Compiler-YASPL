package wrapper;

public class Expression implements GenerationCode {
	
	private String type;
	
	public Expression() {
		
	}

	public String generateCode() {
		return null;
	}	
}
