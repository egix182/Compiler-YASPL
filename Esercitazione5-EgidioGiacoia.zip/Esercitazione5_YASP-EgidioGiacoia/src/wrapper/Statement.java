package wrapper;

public class Statement implements GenerationCode{

	public Statement() {
		
	}
	
	@Override
	public String generateCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
