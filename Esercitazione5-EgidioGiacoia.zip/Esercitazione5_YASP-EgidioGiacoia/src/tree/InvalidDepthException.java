package tree;

public class InvalidDepthException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidDepthException(String err) {
            super (err);
    }
}
