package tree;


public interface Position<E> {
	E element();
}
