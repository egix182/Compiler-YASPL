package tree;

import java.util.Iterator;


public class LinkedTree<E> implements Tree<E>{
	  protected TreePosition<E> root; // reference to the root
	  protected int size;		  // number of nodes
	  
	  /**  Creates an empty tree. */
	  public LinkedTree() { 		    
	    root = null;  // start with an empty tree
	    size = 0;
	  }
	  
	  public LinkedTree(TreePosition<E> root) { 		    
		    this.root = root;
		    size =  this.countNode(this.root());
	  }
	  
	  protected int countNode(Position<E> node) {
		  	int count = 1;
		  	if(this.isInternal(node) == true)
			{	
				 Iterable<Position<E>> it = this.children(node);
				 Iterator<Position<E>> iterator = it.iterator();
				 while(iterator.hasNext())
				 {
					 Position<E> node2 =  iterator.next();
					 count += countNode(node2);
				 }
			}
		  	return count;
	  }
	  
	  
	  
	  
	  public int height (Position<E> v)
	  {
		  TreePosition<E> vv = checkPosition(v);
		  if (isExternal(v))
		  return 0;
		  PositionList<Position<E>> children = vv.getChildren();
		  int max = 0,h = 0;
		  for (Position<E> p : children) {
		  h = height(p);
		  if (h > max)
		  max = h;
		  }
		  return max+1;
	  }
	  
	  public static <E> int numberLeaves(LinkedTree<E> t, Position<E> p)
	  {
		 
		  TreePosition<E> pp = t.checkPosition(p);
		  if(t.isExternal(p)) return 1;
		  int count=0;
		  for(Position<E> pos : pp.getChildren())
			  count += numberLeaves(t,pos);
		  return count;
	  }
	  
	  public boolean ancestor (Position<E> v, Position<E> w)
	  {
		  checkPosition(v);
		  checkPosition(w);
		  
		  if(v == w) return true;
		  else return ancestor(v, parent(w));
	  }
	  
	  public Position<E> ica(Position<E> u, Position<E> v)
	  {
		  Position<E> uu = checkPosition(u);
		  Position<E> vv = checkPosition(v);
		  
		 
		  while(uu!=vv)
		  {
			  if(depth(uu) > depth(vv))
				  uu = parent(u);
			  
			  else vv = parent(vv);
		  }
		  
		  return vv;
	  }
	  
	  public static<E> Iterable<Position<E>> atDepth (Tree<E> T, int i)
	  {
		  PositionList<Position<E>> toReturn = new NodePositionList<Position<E>>();
		  Iterable<Position<E>> list;
		  
		  if(i<0) throw new InvalidDepthException("Errore");
		  else if(i == 0) toReturn.addLast(T.root());
		  else
		  {
			  list = atDepth(T, i-1);
			  for(Position<E> p: list)
			  {
				  if(T.isInternal(p)) 
					  for(Position<E> q: T.children(p))
						  toReturn.addLast(q);
			  }
		  }
		  return toReturn;
	  }
	  
	  /** Returns the number of nodes in the tree. */
	  public int size() {
	    return size; 
	  } 

	  /** Returns whether the tree is empty. */
	  public boolean isEmpty() {
	    return (size == 0); 
	  } 

	  /** Returns whether a node is internal. */
	  public boolean isInternal(Position<E> v) throws InvalidPositionException {
	    return !isExternal(v);
	  }

	  /** Returns whether a node is external. */
	  public boolean isExternal(Position<E> v) throws InvalidPositionException {
	    TreePosition<E> vv = checkPosition(v);	// auxiliary method
	    return (vv.getChildren() == null) || vv.getChildren().isEmpty();
	  }

	  /** Returns whether a node is the root. */
	  public boolean isRoot(Position<E> v) throws InvalidPositionException { 
	    checkPosition(v);
	    return (v == root()); 
	  }

	  /** Returns the root of the tree. */
	  public Position<E> root() throws EmptyTreeException {
	    if (root == null)
	      throw new EmptyTreeException("The tree is empty");
	    return root;
	  } 

	  /** Returns the parent of a node. */
	  public Position<E> parent(Position<E> v) 
	    throws InvalidPositionException, BoundaryViolationException { 
	    TreePosition<E> vv = checkPosition(v);
	    Position<E> parentPos = vv.getParent();
	    if (parentPos == null)
	      throw new BoundaryViolationException("No parent");
	    return parentPos;
	  }
	  /** Returns an iterable collection of the children of a node. */
	  public Iterable<Position<E>> children(Position<E> v) 
	    throws InvalidPositionException { 
	    TreePosition<E> vv = checkPosition(v);
	    if (isExternal(v))
	      throw new InvalidPositionException("External nodes have no children"); 
	    return vv.getChildren();
	  }
	  /** Returns an iterable collection of the tree nodes. */
	  public Iterable<Position<E>> positions() {
	   PositionList<Position<E>> positions = new NodePositionList<Position<E>>();
	    if(size != 0)
	      preorderPositions(root(), positions);  // assign positions in preorder
	    return positions;
	  } 
	 /** Returns an iterator of the elements stored at the nodes */
	  public Iterator<E> iterator() {
	    Iterable<Position<E>> positions = positions();
	   PositionList<E> elements = new NodePositionList<E>();
		   
	   for (Position<E> pos: positions) 
	     elements.addLast(pos.element());
	    return elements.iterator();  // An iterator of elements
	  }
	  /** Replaces the element at a node. */
	  public E replace(Position<E> v, E o) 
	    throws InvalidPositionException {
	    TreePosition<E> vv = checkPosition(v);
	    E temp = v.element();
	    vv.setElement(o);
	    return temp;
	  }
	  
	  /** If v is a good tree node, cast to TreePosition, else throw exception */
	  public TreePosition<E> checkPosition(Position<E> v) 
	    throws InvalidPositionException {
	    if (v == null || !(v instanceof TreePosition))
	      throw new InvalidPositionException("The position is invalid");
	    return (TreePosition<E>) v;
	  }
	  
	  /** Creates a list storing the the nodes in the subtree of a node,
	    * ordered according to the preorder traversal of the subtree. */
	  public void preorderPositions(Position<E> v, PositionList<Position<E>> pos)
	      throws InvalidPositionException {
	    pos.addLast(v);
	    if (isInternal(v))
	    	for (Position<E> w : children(v))
	    		preorderPositions(w, pos);	// recurse on each child
	  }	  
	  
	  public void postorderPositions(Position<E> v, PositionList<Position<E>> pos)
		      throws InvalidPositionException {
		  	pos.addFirst(v);
		    if (isInternal(v))
		    	for (Position<E> w : children(v))
		    		postorderPositions(w, pos);	// recurse on each child
		  }	  
	  
	  public Position<E> insertChild(Position<E> v, E e) throws InvalidPositionException {
		  TreePosition<E> vv = checkPosition(v);
		  TreePosition<E> ww = createNode(e,vv,null);
		  PositionList<Position<E>> children = vv.getChildren(); 
		  if(children == null){
			  children = new NodePositionList<Position<E>>();
			  vv.setChildren(children);
		  }
		  children.addLast(ww);
		  size++;
		  return ww;
	  }
	  

	  /** Adds a root node to an empty tree */
	  public Position<E> addRoot(E e) throws NonEmptyTreeException {
	    if(!isEmpty())
	      throw new NonEmptyTreeException("Tree already has a root");
	    size = 1;
	    root = createNode(e,null,null);
	    return root;
	  }
	  
	  /** Creates a new tree node */
	  protected TreePosition<E> createNode(E element, TreePosition<E> parent, 
					  PositionList<Position<E>> children) {
		  
	    return new TreeNode<E>(element,parent,children); 
	  }
	  

	  
	  /**Depth**/
	  public int depth(Position<E> p)
	  {
		  checkPosition(p);
		  if(isRoot(p)) return 0;
		  else return 1+depth(parent(p));
	  }
	  
	  /**path**/
	  public Iterable<Position<E>> path (Position<E> u, Position<E> v)
	  {
		  TreePosition<E> uu = checkPosition(u);
		  TreePosition<E> vv = checkPosition(v);
		  PositionList<Position<E>> toReturn = new NodePositionList<Position<E>>();
		  
		  
		  while(uu!=vv)
		  {
		  if (depth(uu) > depth(vv))
		  {
			  toReturn.addLast(uu);
			  uu=uu.getParent();
			 
		  }
		  else
		  {
			  toReturn.addLast(vv);
		  vv=vv.getParent();
		 
		  }
		  }
		  
		  toReturn.addLast(vv);
		  return toReturn;
	  }	    
}
